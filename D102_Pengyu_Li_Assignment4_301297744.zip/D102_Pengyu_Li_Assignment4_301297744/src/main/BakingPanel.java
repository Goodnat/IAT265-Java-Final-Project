/*
 * baking panel for initialization, drawing, state setting and mouse event 
 */
package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import ddf.minim.AudioPlayer;
import ddf.minim.Minim;
import decorator.BananaDecorator;
import decorator.ChocolateDecorator;
import decorator.StrawberryDecorator;
import kitchen.BakingBowl;
import kitchen.Banana;
import kitchen.BaseObject;
import kitchen.Bell;
import kitchen.Chocolate;
import kitchen.Clock;
import kitchen.Drop;
import kitchen.End;
import kitchen.Factory;
import kitchen.Fan;
import kitchen.Fridge;
import kitchen.Kitchen;
import kitchen.Milk;
import kitchen.Oven;
import kitchen.Powder;
import kitchen.ProcessingTable;
import kitchen.RestartButton;
import kitchen.StartButton;
import kitchen.Steam;
import kitchen.Strawberry;
import kitchen.Sugar;
import kitchen.Welcome;
import kitchen.Window;
import kitchen.Yeast;
import main.BakingPanel.MyMouseMotionListener;
import main.BakingPanel.MyMouseListener;
import processing.core.PVector;
import util.MinimHelper;
import util.Util;

public class BakingPanel extends JPanel implements ActionListener {
	private static final int W_WIDTH = 1042;//set the width of screen 
	private static final int W_HEIGHT = 680;//set the height of screen

	//set all the states
	public static final int START = 0;
	public static final int TAKEBOWL = 1;
	public static final int ADDPOWDER = 2;
	public static final int OPENFRIDGE = 3;
	public static final int ADDMILK = 4;
	public static final int CLOSEFRIDGE = 5;
	public static final int ADDSUGAR = 6;
	public static final int ADDYEAST = 7;
	public static final int OPENOVEN = 8;
	public static final int CLOSEOVEN = 9;
	public static final int BAKING = 10;
	public static final int BAKEDONE = 11;
	public static final int DRCORATEBREAD = 12;
	public static final int OVER = 13;

	private int state = START;

	// for mouse position
	private double mouseX;
	private double mouseY;

	private JFrame frame;
	
	private Timer timer;

	private Steam steam;

	private int bakeTimer = 0;//set the baking time
	private boolean halfDone = false;

	private Welcome welcome;
	private End end;
	private Factory factory;
	private Kitchen kitchen;
	private Window window;
	private ProcessingTable table;
	private ArrayList<BaseObject> bakingItems;//Array list for the baking items

	private BaseObject clock;
	private BaseObject fan;
	private BaseObject sugar, yeast, powder, milk;
	private BaseObject oven, fridge, bakingBowl;
	private BaseObject selected;
	private BaseObject bread;
	private BaseObject bakedBread;
	private BaseObject strawberry;
	private BaseObject chocolate;
	private BaseObject banana;
	private StartButton startButton;
	private RestartButton restartButton;
	private Bell bell;

	//when used the decorators the item disappear
	private boolean strawberryUsed = false;
	private boolean chocolateUsed = false;
	private boolean bananaUsed = false;

	private Color sunColor, skyColor;
	private ArrayList<Drop> drops;//array list for drops

	private Minim minim;//for music
	private AudioPlayer win, bgm, buttonClick, openOven, itemClick, milkDrop, fridgeOpen, fridgeClose,baking;

	public BakingPanel(JFrame frame) {
		this.setBackground(Color.white);
		setPreferredSize(new Dimension(W_WIDTH, W_HEIGHT));//set screen

		this.frame = frame;//for restart

		initialized();// all initialize items

		startButton = new StartButton(new PVector(850, 500), 0.1);//start button
		restartButton = new RestartButton(new PVector(525, 500), 0.2);//restart button
		bell = new Bell(new PVector(830, 530), 0.08);//bell button
		
		minim = new Minim(new MinimHelper());

		//interactive musics
		bgm = minim.loadFile("bgm.mp3");
		buttonClick = minim.loadFile("button.mp3");
		openOven = minim.loadFile("openoven.mp3");
		itemClick = minim.loadFile("itemClick.mp3");
		milkDrop = minim.loadFile("milkDrop.mp3");
		fridgeOpen = minim.loadFile("fridgeOpen.mp3");
		fridgeClose = minim.loadFile("fridgeClose.mp3");
		baking = minim.loadFile("baking.mp3");
		win = minim.loadFile("win.mp3");
		
		MyMouseListener mml = new MyMouseListener();
		addMouseListener(mml);

		MyMouseMotionListener mmml = new MyMouseMotionListener();
		addMouseMotionListener(mmml);

		timer = new Timer(30, this);
		timer.start();
	}

	public void initialized() {	
		sunColor = new Color(244,84,34);
		skyColor = new Color(34,214,244);
		window = new Window(new PVector(437,110),1,sunColor,skyColor);//the window position
		kitchen = new Kitchen("assets/kitchen.png");//kitchen background
		table = new ProcessingTable("assets/processingTable.png");//the table for decorator
		welcome = new Welcome(new PVector(800, 280), "assets/welcome.png");//welcome screen
		end = new End(new PVector(350, 80));//end screen

		factory = new Factory();//initialize factory
		clock = factory.createObject("clock");//clock

		bakingItems = new ArrayList<BaseObject>();//initialize array list

		//add these items into array list from factory
		oven = factory.createObject("oven");//for oven
		bakingItems.add(oven);

		fan = factory.createObject("fan");//fan
		bakingItems.add(fan);

		fridge = factory.createObject("fridge");//fridge
		bakingItems.add(fridge);

		bakingBowl = factory.createObject("bakingBowl");//baking bowl
		bakingItems.add(bakingBowl);

		bakingItems.add(factory.createObject("yeast"));
		bakingItems.add(factory.createObject("sugar"));
		bakingItems.add(factory.createObject("powder"));

		steam = new Steam((float) oven.getPos().x - 70, (float) oven.getPos().y, 80, 30);//steam
		drops = new ArrayList<Drop>();//drops
		//decorator items
		bakedBread = factory.createObject("bakedBread");
		bread = factory.createObject("bread");

		strawberry = factory.createObject("strawberry");

		chocolate = factory.createObject("chocolate");

		banana = factory.createObject("banana");

		state = START;//the first state is start
	}

	public void dropsAppear() {
		drops.clear();
		//add 50 drops into array list
		for (int i = 0; i < 50; i++) {
			drops.add(new Drop(new PVector((float) mouseX, (float) mouseY),
					new PVector(Util.random(-2, 2), Util.random(-1, -2)), Util.random(0.8, 1)));
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		((Clock) clock).update();//clock running

		window.move();//cloud moving
		//drops moving and disappearing
		for (int i = 0; i < drops.size(); i++) {
			drops.get(i).move();
			if (drops.get(i).disappear()) {
				drops.remove(i);
			}
		}

		if (state == BAKING) {
			((Fan) fan).setRotate();//if state equal to baking the fan rotate
			steam.setWidth(bakeTimer / 2);//set the width of steam
			steam.setHeight(bakeTimer / 10);//set the height of steam
			//the noise add and decrease
			if (!halfDone) {
				bakeTimer++;
				if (bakeTimer >= 270) {
					bakeTimer = 270;//if bake time over 9s set bake time 9s
					halfDone = true;
				}
			} else {
				bakeTimer--;//noise decrease
				if (bakeTimer <= 0) {
					bakeTimer = 0;
					bakingBowl.setPos(oven.getPos());
					state = BAKEDONE;
					((Oven) oven).setOvenImg(1);//close oven change the image to the open oven
				}
			}
		}
		repaint();
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		if (state == START) {
			welcome.drawFarm(g2);//draw the picture in the welcome
			startButton.draw(g2);//draw button 
		} else if (state == OVER) {
			end.drawFarm(g2);//draw the congratulation in the end screen
			bread.draw(g2);//the bread with decorator
			restartButton.draw(g2);//draw restart button
		} else {
			window.draw(g2);//draw window
			kitchen.drawFarm(g2);//draw kitchen
			kitchen.drawRectangle(g2, 100, 80, 80);//draw the recursive pattern
			clock.draw(g2);//draw clock
			oven.draw(g2);//draw oven
			fridge.draw(g2);//draw fridge
			bakingBowl.draw(g2);//draw baking bowl
			fan.draw(g2);//draw fan

			//draw all the baking item
			for (BaseObject bb : bakingItems) {
				bb.draw(g2);
			}
			//draw the drops
			for (Drop drop : drops) {
				drop.draw(g2);
			}

			//when state equal to baking draw steam
			if (state == BAKING) {
				steam.drawSteam(g2);
			}

			//when state equal to BAKEDONE draw baked bread
			if (state == BAKEDONE) {
				bakedBread.draw(g2);
			}
			
			//when state equal to DRCORATEBREAD draw all decorator items
			if (state == DRCORATEBREAD) {
				table.drawFarm(g2);
				bread.draw(g2);
				if (strawberryUsed == false) {
					strawberry.draw(g2);
				}
				if (chocolateUsed == false) {
					chocolate.draw(g2);
				}
				if (bananaUsed == false) {
					banana.draw(g2);
				}
				bell.draw(g2);
			}			
			
			/*
			 * draw string of every step at the bottom of the screen
			 */
			g2.setColor(new Color(252,134,99));//font color
			g2.scale(2,2);//font size

			g2.translate(-350,-170);//move messages to the bottom
			if (state == TAKEBOWL) {
				g2.drawString("Please take the bowl in the closet to the cooktop", 500, 500);
			}else if (state == ADDPOWDER) {
				g2.drawString("Add powder into the bowl", 500, 500);
			}else if (state == OPENFRIDGE) {
				g2.drawString("Open the fridge", 500, 500);
			}else if (state ==  ADDMILK) {
				g2.drawString("Add milk into the bowl", 500, 500);
			}else if (state == CLOSEFRIDGE) {
				g2.drawString("Close the fridge", 500, 500);
			}else if (state == ADDSUGAR) {
				g2.drawString("Add suger into the bowl", 500, 500);
			}else if (state ==  ADDYEAST) {
				g2.drawString("Add yeast into the bowl", 500, 500);
			}else if (state == OPENOVEN) {
				g2.drawString("Open the oven on the right side", 500, 500);
			}else if (state == CLOSEOVEN) {
				g2.drawString("Put the bowl into the oven", 500, 500);
			}else if (state == BAKING) {
				g2.drawString("Wait for the baking to finish", 500, 500);
			}else if (state == BAKEDONE) {
				g2.drawString("Click the bread in the oven", 500, 500);
			}else if (state == DRCORATEBREAD) {
				g2.drawString("Put the food you like on the bread then click the DONE button", 500, 500);
			}		
		}
	}

	public class MyMouseListener extends MouseAdapter {

		public void mousePressed(MouseEvent e) {
			mouseX = e.getX();//get the mouse x position
			mouseY = e.getY();//get the mouse y position
			selected = null;

			//baking item can be selected
			for (int i = bakingItems.size() - 1; i > -1; i--) {
				BaseObject bakingItem = bakingItems.get(i);
				if (bakingItem.isClicked(mouseX, mouseY)) {
					selected = bakingItem;
					break;
				}
			}

			if (state == START) {
				if (startButton.isClicked(mouseX, mouseY)) {
					buttonClick.play(0);//button pressed sound
					state = TAKEBOWL;//state change to TAKEBOWL when clicked start
					bgm.loop();//bgm play
				}
			} else if (state == OVER) {
				if (restartButton.isClicked(mouseX, mouseY)) {
					buttonClick.play(0);//button pressed sound
					//game restart
					frame.dispose();
					new BakingApp("BakingApp");
				}
			}
			
			if (state == TAKEBOWL) {
				if (bakingBowl.isClicked(mouseX, mouseY)) {
					itemClick.play(0);
					state = ADDPOWDER;//change to state of ADDPOWDER
				}
			}

			if (state == OPENOVEN) {
				if (oven.isClicked(mouseX, mouseY)) {
					openOven.play(0);//close oven change to open oven
				}
			}
			if (state == DRCORATEBREAD) {
				//banana can be selected
				if (banana.isClicked(mouseX, mouseY)) {
					selected = banana;
				}
				//strawberry can be selected
				if (strawberry.isClicked(mouseX, mouseY)) {
					selected = strawberry;
				}
				//chocolate can be selected
				if (chocolate.isClicked(mouseX, mouseY)) {
					selected = chocolate;
				}
				//when the done button pressed the game to the end screen
				if (bell.isClicked(mouseX, mouseY)) {
					buttonClick.play(0);
					state = OVER;
					win.play(0);
					bgm.close();//bgm stop
				}
			}
		}

		public void mouseReleased(MouseEvent e) {
			if (state == ADDPOWDER) { // take powder into bowl
				if (selected instanceof Powder && selected.collision(bakingBowl)) {
					dropsAppear();//drops appear
					bakingItems.remove(selected);//powder disappear
					itemClick.play(0);
					selected = null;
					bakingBowl.setTouch(false);
					state = OPENFRIDGE;//switch state 
				}
			}
			if (state == OPENFRIDGE) { // open the fridge
				if (selected instanceof Fridge) {
					fridgeOpen.play(0);
					((Fridge) fridge).setFridgeImg(1);//fridge changed to the open state
					milk = factory.createObject("milk");//when the fridge open milk appear
					bakingItems.add(milk);
					state = ADDMILK;//switch state 
				}
			}
			if (state == ADDMILK) { // take milk into bowl
				if (selected instanceof Milk && selected.collision(bakingBowl)) {
					dropsAppear();//drops appear
					bakingItems.remove(selected);//milk disappear
					milkDrop.play(0);
					selected = null;
					bakingBowl.setTouch(false);
					state = CLOSEFRIDGE;//switch state 
				}
			}
			if (state == CLOSEFRIDGE) { // close the fridge
				if (selected instanceof Fridge) {
					fridgeClose.play(0);
					((Fridge) fridge).setFridgeImg(0);//change the open fridge to close fridge
					state = ADDYEAST;//switch state 
				}
			}
			if (state == ADDYEAST) { // take yeast into bowl
				if (selected instanceof Yeast && selected.collision(bakingBowl)) {
					dropsAppear();//drops appear
					bakingItems.remove(selected);//yeast disappear
					itemClick.play(0);
					selected = null;
					bakingBowl.setTouch(false);
					state = ADDSUGAR;//switch state 
				}
			}
			if (state == ADDSUGAR) { // take sugar into bowl
				if (selected instanceof Sugar && selected.collision(bakingBowl)) {
					dropsAppear();//drops appear
					bakingItems.remove(selected);//sugar disappear
					itemClick.play(0);
					selected = null;
					bakingBowl.setTouch(false);
					state = OPENOVEN;//switch state 
				}
			}
			if (state == OPENOVEN) { // open the oven
				if (selected instanceof Oven) {
					((Oven) oven).setOvenImg(1);//change close oven to open oven
					state = CLOSEOVEN;//switch state 
				}
			}
			if (state == CLOSEOVEN) { // close the oven
				if (selected instanceof BakingBowl && selected.hit(oven)) {
					fridgeClose.play(0);
					bakingItems.remove(selected);//baking bowl disappear
					((Oven) oven).setOvenImg(2);//set open oven to close ovan with bread
					baking.play(0);
					sunColor = new Color(255,241,141);
					skyColor = new Color(4,53,61);
					window = new Window(new PVector(437,110),1,sunColor,skyColor);
					selected = null;
					bakingBowl.setTouch(false);
					state = BAKING;//switch state 
				}
			}
			if (state == BAKING) { // open the fan
				if (selected instanceof Fan) {
					((Fan) fan).setRotate();//when state BAKING can use mouse click to control the fan rotate or not
				}
			}
			if (state == BAKEDONE) {
				if (selected instanceof Oven) {
					((Oven) oven).setOvenImg(1);//change the open to be open
					state = DRCORATEBREAD;//switch state
				}
			}

			if (state == DRCORATEBREAD) {
				if (selected instanceof Strawberry && selected.collision(bread)) {
					itemClick.play(0);
					bread = new StrawberryDecorator(bread, new PVector((int) mouseX, (int) mouseY));//when the strawberry decorator collision to the bread get the new bread
					strawberryUsed = true;//strawberry disappear
				}

				if (selected instanceof Chocolate && selected.collision(bread)) {
					itemClick.play(0);
					bread = new ChocolateDecorator(bread, new PVector((int) mouseX, (int) mouseY));//when the chocolate decorator collision to the bread get the new bread
					chocolateUsed = true;//chocolate disappear
				}

				if (selected instanceof Banana && selected.collision(bread)) {
					itemClick.play(0);
					bread = new BananaDecorator(bread, new PVector((int) mouseX, (int) mouseY));//when the banana decorator collision to the bread get the new bread
					bananaUsed = true;//banana disappear
				}
			}
		}
	}

	public class MyMouseMotionListener extends MouseMotionAdapter {

		public void mouseDragged(MouseEvent e) {
			mouseX = e.getX();//get mouse x position
			mouseY = e.getY();//get mouse y position

			//item except oven fan and fridge all can be dragged 
			if (selected != null) {
				if (selected != oven && selected != fan && selected != fridge) {
					selected.setPos(new PVector((float) mouseX, (float) mouseY));
				}
			}

			//every item get into bowl the size of bowl will increase
			if (selected != null && !(selected instanceof BakingBowl)) {
				bakingBowl.setTouch(false);
				if (selected.collision(bakingBowl)) {
					bakingBowl.setTouch(true);
				}
			}

			//when the bowl hit to the oven the size of oven increase
			if (selected != null && !(selected instanceof Oven)) {
				oven.setTouch(false);
				if (selected.hit(oven)) {
					oven.setTouch(true);
				}
			}

			repaint();

		}
	}
}
