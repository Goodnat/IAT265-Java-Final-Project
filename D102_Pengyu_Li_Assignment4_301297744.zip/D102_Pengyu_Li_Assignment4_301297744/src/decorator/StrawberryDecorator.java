/*
 * this is the strawberry decorator
 */
package decorator;

import kitchen.BaseObject;
import processing.core.PVector;
import util.ImageLoader;


//draw the lamp 
public class StrawberryDecorator extends BananaDecorator{
	// constructor
	public StrawberryDecorator(BaseObject bread, PVector pos) {
		super(bread,pos);
		img = ImageLoader.loadImage("assets/strawberry.png");//load image
	}

}
