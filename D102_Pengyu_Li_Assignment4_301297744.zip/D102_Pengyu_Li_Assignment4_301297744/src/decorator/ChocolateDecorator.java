/*
 * this is the chocolate decorator
 */
package decorator;

import kitchen.BaseObject;
import processing.core.PVector;
import util.ImageLoader;


//draw the lamp 
public class ChocolateDecorator extends BananaDecorator{

	// constructor
	public ChocolateDecorator(BaseObject bread, PVector pos) {
		super(bread,pos);
		img = ImageLoader.loadImage("assets/chocolate.png");//load image
	}


}
