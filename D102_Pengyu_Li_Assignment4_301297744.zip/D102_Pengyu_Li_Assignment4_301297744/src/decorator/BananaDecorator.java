/*
 * this is the banana decorator
 */
package decorator;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import kitchen.BaseObject;
import processing.core.PVector;
import util.ImageLoader;

public class BananaDecorator extends BaseObject{
	private BaseObject bread;
	// constructor
	public BananaDecorator(BaseObject bread, PVector pos) {
		super(bread.getPos(), 0.04);
		this.pos=pos;
		this.bread = bread;
		img = ImageLoader.loadImage("assets/bananaPiece.png");//load image
	}

	@Override
	public void draw(Graphics2D g2) {
		bread.draw(g2);//draw bread first

		AffineTransform transform = g2.getTransform(); // save(x~y)
		g2.translate(pos.x, pos.y);
		g2.scale(scale, scale);
		g2.drawImage(img, -img.getWidth()/2, -img.getHeight()/2, null);//draw banana on the bread
		g2.setTransform(transform);
		
	}

}
