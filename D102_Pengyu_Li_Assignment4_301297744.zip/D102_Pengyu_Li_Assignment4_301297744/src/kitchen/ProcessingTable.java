/*
 * the processing table to decorator the bread
 */
package kitchen;

import java.awt.*;
import java.awt.image.BufferedImage;

import util.ImageLoader;

public class ProcessingTable{
	private BufferedImage img;

	public ProcessingTable(String file) {
		img = ImageLoader.loadImage(file);//load image
	}

	public void drawFarm(Graphics2D g2) {
		g2.scale(1, 1);
		g2.drawImage(img, 0, 0, 1042, 625,null);//draw image
	}

}
