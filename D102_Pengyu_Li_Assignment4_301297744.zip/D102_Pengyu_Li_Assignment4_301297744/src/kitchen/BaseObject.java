/*
 * the baseObject is father class/ super class.
 */
package kitchen;
import java.awt.Graphics2D;
	import java.awt.image.BufferedImage;

	import processing.core.PVector;

public abstract class BaseObject {

		protected PVector pos; // position
        protected PVector vel; // speed
		protected int width;
		protected int height;
		protected double scale;
		protected boolean selected;
		protected boolean touch;		
		protected BufferedImage img;		
		protected int state;	

		public BaseObject(PVector pos, double scale) {
			this.pos = pos;
			this.vel = new PVector();
			this.scale = scale;
		}

		//abstract class of draw
		public abstract void draw(Graphics2D g2);
		
		//judge the two item collision
		public boolean collision(BaseObject other) {

			return Math.abs(pos.x - other.pos.x) < (width * scale + other.width * other.scale) / 2.0 && Math.abs(pos.y - other.pos.y) < (height * scale+ other.height * other.scale) / 2.0;
			
		}
		
		//two items hit
		public boolean hit(BaseObject other) {
			return PVector.dist(pos, other.pos) < 20;
		}
		
		public boolean isClicked(double x, double y){
			boolean clicked = false;
			
			if (x > (pos.x - width / 2.0 * scale) && x < (pos.x + width / 2.0  * scale) && y > (pos.y - height / 2.0 * scale) && y < (pos.y + height / 2.0 * scale)) {
				clicked = true;
			}
		
			return clicked;
		}
		
		//get touch true or false
		public boolean getTouch() {
			return touch;
		}
		
		//set touch true or false
		public void setTouch(boolean t) {
			touch = t;
		}
		
		//get position
		public PVector getPos() {
			return pos;
		}	
		
		//set position
		public void setPos(PVector pos) {
			this.pos = pos;
		}

		public BufferedImage getImage() {
			return img;
		}
	}


