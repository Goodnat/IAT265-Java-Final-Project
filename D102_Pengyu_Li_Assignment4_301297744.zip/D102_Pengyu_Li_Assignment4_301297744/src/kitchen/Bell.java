/*
 * the class of bell appear in the state of DRCORATEBREAD.
 */
package kitchen;

import processing.core.PVector;
import util.ImageLoader;

	public class Bell extends StartButton{
		// constructor
		public Bell(PVector pos, double scale) {
			super(pos, scale);
			img = ImageLoader.loadImage("assets/bell.png");//load image
		}
}

