/*
 * the welcome screen in the begin.
 */
package kitchen;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.image.BufferedImage;

import processing.core.PVector;
import util.ImageLoader;

public class Welcome{
	
	private GeneralPath starPath;
	private PVector pos;
	private BufferedImage img;
	
	public Welcome(PVector pos,String file) {
		this.pos = pos;
		img = ImageLoader.loadImage(file);//load image
	}

	public void drawFarm(Graphics2D g2) {	
		//background
		g2.setColor(new Color(253,246,190));
		g2.fillRect(0, 0, 1042, 680);
		
		g2.drawImage(img, 50, 90, 536, 456, null);//draw image
		AffineTransform transform = g2.getTransform(); // save(x~y)
		g2.translate(pos.x, pos.y);
		g2.scale(1, 1);

		
		//draw the star
		int xPoints[] = { 55, 67, 110, 73, 83, 55, 27, 37, 1, 43 };
		int yPoints[] = { 0, 35, 35, 55, 96, 72, 96, 55, 36, 35 };
		starPath = new GeneralPath();
		// set the initial coordinate
		starPath.moveTo(xPoints[0], yPoints[0]);
		// create the star
		for (int i = 1; i < xPoints.length; i++) {
		starPath.lineTo(xPoints[i], yPoints[i]);
		}
		starPath.closePath(); 
		
		g2.setColor(new Color(252,134,99));//set color
		g2.fill(starPath);
		g2.scale(3, 3);
		g2.drawString("BAKING TIME", -20, -30);//draw string
		
		g2.setTransform(transform);
		
		
	}
	
}
