/*
 * the class of drops appear when the item add into the bowl.
 */
package kitchen;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

import processing.core.PVector;
 
public class Drop extends BaseObject{
	private Rectangle2D.Double drop;
	private float d = 10;
	private float gravity;
	// constructor
	public Drop(PVector pos, PVector vel, double scale) {
		super(pos, scale);
		gravity = 0.1f;//gravity of drops
		this.vel = vel;
		d = 10;
		drop = new Rectangle2D.Double(0, 0, d, d);
	}

	@Override
	public void draw(Graphics2D g2) {
		AffineTransform transform = g2.getTransform(); // save(x~y)
		g2.translate(pos.x, pos.y);
		g2.scale(scale, scale);
		g2.setColor(Color.white);
		drop.setFrame(0, 0, d, d);
		g2.fill(drop);//draw drops
		g2.setTransform(transform);
	}
	
	//when d<=0 drops disappear
	public boolean disappear() {
		if (d <= 0) {
			return true;
		}
		return false;
	}
	
	//the move of drops
	public void move() {
		d -= 0.2;
		vel.y += gravity;
		pos.add(vel);
	}

	//update method
	public void update() {
		move();
		disappear();
	}
}
