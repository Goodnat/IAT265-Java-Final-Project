/*
 * the class of milk item in the kitchen
 */
package kitchen;

import processing.core.PVector;
import util.ImageLoader;

public class Powder extends Milk{

	public Powder(PVector pos, double scale) {
		super(pos, scale);
		img = ImageLoader.loadImage("assets/powder.png");//load image
	}

}
