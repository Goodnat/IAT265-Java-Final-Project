/*
 * the class of bread appear in the state of DRCORATEBREAD.
 */
package kitchen;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

import processing.core.PVector;
import util.ImageLoader;

public class Bread extends BaseObject{

	public Bread(PVector pos, double scale) {
		super(pos, scale);
		img = ImageLoader.loadImage("assets/orignalBread.png");//load image
		width = (int)(img.getWidth());//width of image
		height = (int)(img.getHeight());//height of image
	}

	@Override
	public void draw(Graphics2D g2) {
		AffineTransform transform = g2.getTransform(); 
		g2.translate(pos.x, pos.y);
		if (touch) {
			g2.scale(scale + 0.1, scale + 0.1);
		}else {
			g2.scale(scale, scale);
		}
		g2.drawImage(img, -width/2, -height/2, width, height, null);
		g2.setTransform(transform);
	}
	

}
