/*
 * the class of baked bread appear after oven open.
 */
package kitchen;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

import processing.core.PVector;

//draw the lamp 
public class BakingBowl extends BaseObject{
	private Rectangle2D.Double shape;
	public BakingBowl(PVector pos, double scale) {
		super(pos, scale);
		width = 80;
		height = 100;
		shape = new Rectangle2D.Double(-50, -25, 100, 60);//draw the bowl
	}

	@Override
	public void draw(Graphics2D g2) {
		AffineTransform transform = g2.getTransform(); // save(x~y)
		g2.translate(pos.x, pos.y);
		//when touched it will increase size
		if (touch) {
			g2.scale(scale + 0.1, scale + 0.1);
		}else {
			g2.scale(scale, scale);
		}
		g2.setColor(Color.GRAY);
		g2.fill(shape);//draw bowl
		g2.setColor(Color.white);
		g2.drawString("Baking Bowl", -33, 8);//draw string
		g2.setTransform(transform);
	}
}