/*
 * the class of yeast in the kitchen.
 */
package kitchen;

import processing.core.PVector;
import util.ImageLoader;

public class Yeast extends Milk{

	public Yeast(PVector pos, double scale) {
		super(pos, scale);
		img = ImageLoader.loadImage("assets/yeast.png");//load image
	}

}
