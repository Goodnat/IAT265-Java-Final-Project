/*
 * the class of fridge in the kitchen.
 */
package kitchen;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import util.ImageLoader;

public class Kitchen {
	private BufferedImage img;

	public Kitchen(String file) {
		img = ImageLoader.loadImage(file);//load image
	}

	public void drawFarm(Graphics2D g2) {
		g2.scale(1, 1);
		g2.drawImage(img, 0, 0, 1042, 625, null);//draw image
	}

	public void drawRectangle(Graphics2D g2, float x, float y, float d) { // d - diameter
		AffineTransform at = g2.getTransform();
		g2.translate(x+423, y+425);
		g2.scale(0.3, 0.3);
		g2.setColor(Color.white);
		g2.draw(new Rectangle2D.Double(-d / 2, -d / 2, d, d));
		g2.setTransform(at);
		if (d > 10) {
			d *= 0.5; // shrink d by 50% each recursion
			drawRectangle(g2, x + d, y, d);
			drawRectangle(g2, x - d, y, d);
			drawRectangle(g2, x, y + d, d);
			drawRectangle(g2, x, y - d, d);
		}
	}
}
