/*
 * the class of clock
 */
package kitchen;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.Calendar;

import processing.core.PVector;

public class Clock extends BaseObject {
	private int hour;
	private int minute;
	private int second; 
	private Calendar calendar;

	public Clock(PVector pos, double scale) {
		super(pos, scale);
		width = 220;//width of clock
		height = 220;//height of clock
	}

	@Override
	public void draw(Graphics2D g) {
		AffineTransform trans = g.getTransform();
		g.translate(pos.x, pos.y);
		g.scale(scale, scale);

		//the outline of the clock
		g.setColor(Color.black);
		g.setStroke(new BasicStroke(15));
		g.drawRect(-width / 2, -height / 2, width, height);
		g.setColor(new Color(233,233,233));
		g.fillRect(-width / 2, -height / 2, width, height);
		
		//draw line in the clock
		AffineTransform at = g.getTransform();
		for (int i = 0; i < 60; i++) {
			g.setColor(new Color(103,174,168));
			if (i % 5 == 0) {
				g.setStroke(new BasicStroke(4));
				g.drawLine(70, 0, 100, 0);
			} else {
				g.setStroke(new BasicStroke(1));
				g.drawLine(80, 0, 100, 0);
			}
			g.rotate(Math.toRadians(6));
		}
		
		g.setTransform(at);
		
		//hours hand
		at = g.getTransform();
		if (hour > 12)
			hour -= 12;
		g.rotate(Math.toRadians((hour + second / 60.0) * 360 / 12.0));
		g.setStroke(new BasicStroke(5));
		g.setColor(new Color(244,116,69));
		g.drawLine(0, 0, 0, -40);
		g.setTransform(at);

		//seconds hand
		at = g.getTransform();
		g.rotate(Math.toRadians(second * 360 / 60.0));
		g.setColor(new Color(48,48,48));
		g.setStroke(new BasicStroke(1));
		g.drawLine(0, 0, 0, -80);
		g.setTransform(at);

		// minutes hand
		at = g.getTransform();
		g.rotate(Math.toRadians((minute + second / 60.0) * 360 / 60.0));
		g.setStroke(new BasicStroke(4));
		g.drawLine(0, 0, 0, -60);
		g.setTransform(at);
		
		g.setTransform(trans);
	}

	public void update() {
		calendar = Calendar.getInstance();
		second = calendar.get(Calendar.SECOND);
		minute = calendar.get(Calendar.MINUTE);
		hour = calendar.get(Calendar.HOUR_OF_DAY);
	}
}
