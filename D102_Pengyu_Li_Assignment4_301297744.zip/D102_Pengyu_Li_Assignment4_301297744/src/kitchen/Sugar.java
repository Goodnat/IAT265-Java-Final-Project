/*
 * the class of sugar in the kitchen.
 */
package kitchen;

import processing.core.PVector;
import util.ImageLoader;

public class Sugar extends Milk{

	public Sugar(PVector pos, double scale) {
		super(pos, scale);
		img = ImageLoader.loadImage("assets/suger.png");//load image
	}
	
}
