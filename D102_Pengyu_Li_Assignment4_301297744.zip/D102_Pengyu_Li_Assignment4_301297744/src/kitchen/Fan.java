/*
 * the class of fan draw in the kitchen.
 */
package kitchen;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;

import processing.core.PVector;


public class Fan extends BaseObject{
	private GeneralPath gPath;// general path
	private float angle = 0;
	private Rectangle2D.Double shell;
	private boolean rotate;
	

	public Fan(PVector pos, float scale) {
		super(pos, scale);
		width = 100;
		height = 100;
		gPath = new GeneralPath();
		setShapeAttributes();
		shell = new Rectangle2D.Double(-width / 2,-height /2, width, height);
	}

	public void setShapeAttributes() {
		//the coordinate of sector
		int xPoints[] = {0, 30, 30};
		int yPoints[] = {0, -20, 20};
		
		gPath.moveTo(xPoints[0], yPoints[0]);
		
		// create the star--this does not draw the star
		for (int index = 1; index < xPoints.length; index++) {
			gPath.lineTo(xPoints[index], yPoints[index]);
		}
		
		gPath.closePath();	// close the shape
	}

	@Override
	public void draw(Graphics2D g) {
		AffineTransform at = g.getTransform();
		g.translate(pos.x, pos.y);
		g.scale(scale, scale);
		g.setStroke(new BasicStroke(5));//set the stroke of the shell of the clock
		g.setColor(new Color(189,189,189));
		g.fill(shell);//draw shell
		g.setColor(Color.white);
		g.fillOval(-45, -45, 90, 90);
	
		g.setColor(new Color(189,189,189));
		AffineTransform at1 = g.getTransform();
		//rotate the fan
		if (rotate) {
			angle += 0.5;
			g.rotate(angle);
		}
		AffineTransform at2 = g.getTransform();

		//draw sector
		for (int i = 0; i < 4; i++) {
			g.fillArc(-5, -23, 45, 45, -60, 120);
			g.fill(gPath);
			g.rotate(Math.toRadians(90));
		}
		
		g.setTransform(at2);
		g.setTransform(at1);
		
		g.setColor(new Color(189,189,189));
		g.fillOval(-8, -8, 16, 16);
		
		g.setTransform(at);
	}

	public void setRotate() {
		rotate = !rotate;
	}
}