/*
 * the window in the kitchen.
 */
package kitchen;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

import processing.core.PVector;

public class Window extends BaseObject {

	private int move;
	private Color suncolor;
	private Color skycolor;

	public Window(PVector pos, double scale, Color suncolor, Color skycolor) {
		super(pos, scale);
		width = 338;
		height = 160;
		this.suncolor =suncolor;
		this.skycolor = skycolor;
	}

	@Override
	public void draw(Graphics2D g2) {
		AffineTransform transform = g2.getTransform();
		g2.translate(pos.x, pos.y);
		//draw the window
		g2.setColor(new Color(233, 233, 233));
		g2.fillRect(-width / 2, -height / 2, width, height);
		g2.setColor(skycolor);
		g2.fillRect(-width / 2 + 10, -height / 2 + 10, width - 20, height - 20);
		// draw the clouds
		g2.setColor(suncolor);
		g2.fillOval(-230 + move, -40, 60, 60);
		g2.setColor(Color.white);
		g2.fillOval(0 + move, 0, 60, 40);
		g2.fillOval(20 + move, 5, 60, 40);
		g2.fillOval(20 + move, -10, 60, 40);
		g2.fillOval(-80 + move, -50, 60, 40);
		g2.fillOval(-60 + move, -45, 60, 40);
		g2.fillOval(-60 + move, -60, 60, 40);
		g2.setTransform(transform);
	}

	//clouds move
	public void move() {
		move++;
		if (move >= 400) {
			move = -220;
		}
	}
}
