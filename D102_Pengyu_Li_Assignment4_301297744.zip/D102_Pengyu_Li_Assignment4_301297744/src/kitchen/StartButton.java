/*
 * start button appear in the state equal to welcome
 */
package kitchen;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import processing.core.PVector;
import util.ImageLoader;

	public class StartButton extends BaseObject{
		// constructor
		public StartButton(PVector pos, double scale) {
			super(pos, scale);
			img = ImageLoader.loadImage("assets/start.png");//load image
			width = (int)(img.getWidth());//width of image
			height = (int)(img.getHeight());//height of image
		}

		public void draw(Graphics2D g2) {
			AffineTransform transform = g2.getTransform(); 
			g2.translate(pos.x, pos.y);

			g2.scale(scale, scale);

			g2.drawImage(img, -width/2, -height/2, width, height, null);//draw image
			g2.setTransform(transform);
		}
}

