/*
 * the class of fridge in the kitchen.
 */
package kitchen;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

import processing.core.PVector;
import util.ImageLoader;

public class Fridge extends BaseObject{
	private int state;
	// constructor
	public Fridge(PVector pos, double scale) {
		super(pos, scale);
		
		img = ImageLoader.loadImage("assets/fridgeClose.png");//load image
		width = (int)(img.getWidth());//width of image
		height = (int)(img.getHeight());//height of image
		
	}

	@Override
	public void draw(Graphics2D g2) {
		AffineTransform trans = g2.getTransform();
		g2.translate(pos.x, pos.y);
		//when mouse touched it will increase size
		if (touch) {
			g2.scale(scale + 0.1, scale + 0.1);
		}else {
			g2.scale(scale, scale);
		}
		g2.drawImage(img, -img.getWidth() / 2, -img.getHeight() / 2, null);

		g2.setTransform(trans);
	}
	
	public void setFridgeImg(int fridgeState) {

	    if (fridgeState == 0) {
	    	state = 0;
	        img = ImageLoader.loadImage("assets/fridgeClose.png");  //close oven
	    }else if (fridgeState == 1) {
	    	state = 1;
	        img = ImageLoader.loadImage("assets/fridgeOpen.png");   //open oven
	    }
	}
	
	public int getState() {
		return state;
	}

}