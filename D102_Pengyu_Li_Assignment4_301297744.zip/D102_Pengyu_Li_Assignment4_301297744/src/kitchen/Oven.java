/*
 * the class of oven in the kitchen.
 */
package kitchen;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

import processing.core.PVector;
import util.ImageLoader;

public class Oven extends BaseObject{
	private int state;
	// constructor
	public Oven(PVector pos, double scale) {
		super(pos, scale);
		
		img = ImageLoader.loadImage("assets/ovenClose.png");//load image
		width = (int)(img.getWidth());
		height = (int)(img.getHeight());
		
	}

	@Override
	public void draw(Graphics2D g2) {
		AffineTransform trans = g2.getTransform();//safe x,y
		g2.translate(pos.x, pos.y);
		//when items touched it will increase the size
		if (touch) {
			g2.scale(scale + 0.02, scale + 0.02);
		}else {
			g2.scale(scale, scale);
		}
		
		g2.drawImage(img, -img.getWidth() / 2, -img.getHeight() / 2, null);//draw image

		g2.setTransform(trans);
	}
	
	public void setOvenImg(int ovenState) {

	    if (ovenState == 0) {
	    	state = 0;
	        img = ImageLoader.loadImage("assets/ovenClose.png");  //close oven
	    }else if (ovenState == 1) {
	    	state = 1;
	        img = ImageLoader.loadImage("assets/ovenOpen.png");   //open oven
	    }
	    else if (ovenState == 2) {
	        img = ImageLoader.loadImage("assets/ovenBaking.png"); //close oven and bake
	        state = 2;
	    }
	}
	
	public int getState() {
		return state;
	}

}