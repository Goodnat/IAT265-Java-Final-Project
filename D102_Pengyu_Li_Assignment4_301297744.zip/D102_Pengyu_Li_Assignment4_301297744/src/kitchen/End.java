/*
 * End screen.
 */
package kitchen;

import java.awt.*;
import java.awt.geom.AffineTransform;

import processing.core.PVector;

public class End {

	private PVector pos;

	public End(PVector pos) {
		this.pos = pos;
	}

	public void drawFarm(Graphics2D g2) {
		//background
		g2.setColor(new Color(180,220,183));
		g2.fillRect(0, 0, 1042, 680);
		
		AffineTransform transform = g2.getTransform(); // save x,y
		g2.translate(pos.x, pos.y);
		g2.setColor(new Color(252, 134, 99));//set color of font
		g2.scale(3, 3);
		g2.drawString("CONGRATULATION", 0, 0);//draw string
		g2.setTransform(transform);

	}

}