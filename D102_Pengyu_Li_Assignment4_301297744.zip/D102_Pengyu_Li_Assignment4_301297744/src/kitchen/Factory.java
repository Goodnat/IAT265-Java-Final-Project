/*
 * the class of factory
 */
package kitchen;

import processing.core.PVector;

public class Factory {
	
	public BaseObject createObject(String type) {
		if (type.equals("clock")) {
			return new Clock(new PVector(190, 70),0.4);//position and scale
		}else if (type.equals("sugar")) {
			return new Sugar(new PVector(460, 235),0.2);//position and scale
		}else if (type.equals("yeast")) {
			return new Yeast(new PVector(520, 235),0.2);//position and scale
		}else if (type.equals("powder")) {
			return new Powder(new PVector(580, 235),0.2);//position and scale 
		}else if (type.equals("milk")) {
			return new Milk(new PVector(150, 235),0.2);//position and scale 
		}else if (type.equals("oven")) {
			return new Oven(new PVector(930, 338),0.12);//position and scale
		}else if (type.equals("fridge")) {
			return new Fridge(new PVector(150, 340),0.12);//position and scale
		}else if (type.equals("bakingBowl")) {
			return new BakingBowl(new PVector(930, 77),1);//position and scale
		}else if (type.equals("fan")) {
			return new Fan(new PVector(730, 100),1);//position and scale 
		}else if (type.equals("bread")) {
			return new Bread(new PVector(520, 280), 0.1);//position and scale 
		}else if (type.equals("bakedBread")) {
			return new BakedBread(new PVector(930, 340), 0.03);//position and scale 
		}else if (type.equals("strawberry")) {
			return new Strawberry(new PVector(280, 200),0.07);//position and scale 
		}else if (type.equals("chocolate")) {
			return new Chocolate(new PVector(780, 200),0.08);//position and scale 
		}else if (type.equals("banana")) {
			return new Banana(new PVector(260, 300),0.1);//position and scale 
		}else return null;
	}
}
