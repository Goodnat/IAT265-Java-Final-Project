/*
 * restart button appear in the state equal to end
 */
package kitchen;

import processing.core.PVector;
import util.ImageLoader;

	public class RestartButton extends StartButton{
		// constructor
		public RestartButton(PVector pos, double scale) {
			super(pos, scale);
			img = ImageLoader.loadImage("assets/restart.png");//load image
			width = (int)(img.getWidth());//width of image
			height = (int)(img.getHeight());//height of image
		}
}

